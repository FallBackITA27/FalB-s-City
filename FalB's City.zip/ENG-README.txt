So:
This is a world which tries to emulate a city.
Just be sure to put the world's files in the right folder
or any information: youtube.com/channel/UCq8DZDldrbqdtVtZZxmJNgg

-FalB
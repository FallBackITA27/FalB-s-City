So:
This is a world which is full of Minigames (Kinda).
Just be sure to put the world's files in the right folder
or any information: youtube.com/channel/UCq8DZDldrbqdtVtZZxmJNgg

-FalB